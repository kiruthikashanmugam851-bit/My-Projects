-- DATA TRANSFORMATION
USE ecommerce;

-- column renaming
ALTER TABLE customer_churn
RENAME COLUMN PreferedOrderCat
TO PreferredOrderCat;

ALTER TABLE customer_churn
RENAME COLUMN HourSpendOnApp
TO HoursSpentOnApp;

-- New column creation
ALTER TABLE customer_churn
ADD COLUMN ComplaintReceived varchar(10);

UPDATE customer_churn
SET ComplaintReceived = 
    CASE 
       WHEN Complain = 1 then 'Yes'
       ELSE 'No'
    End;   
    
ALTER TABLE customer_churn
ADD COLUMN ChurnStatus varchar(10);

UPDATE customer_churn
SET ChurnStatus =
    CASE 
	   WHEN Churn = 1 then 'Churned'
       ELSE 'Active'
    END;

ALTER TABLE customer_churn
DROP Complain,
DROP Churn;


-- DATA EXPLORATION AND ANALYZE

--  count of churned and active customers
 
 USE ecommerce;
       SELECT ChurnStatus,
       COUNT(*) AS CustomerCount
       FROM customer_churn
       GROUP BY ChurnStatus;
       
   -- average tenure and total cashback

       SELECT
           avg(Tenure) AS AvgTenure,
           sum(CashbackAmount) AS TotalCashBack
	   FROM customer_churn
       WHERE ChurnStatus = 'Churned';
       
    -- % of complained customers

	   SELECT 
           (count(case when complaintreceived = 
							'Yes' then 1 end) * 100.0 / count(*))as Complaintpercentage
       FROM customer_churn
       where ChurnStatus = 'Churned';
       
    -- 

       SELECT CityTier,
       count(*) as ChrunedCount
       FROM customer_churn
       WHERE ChurnStatus = 'Churned'
          AND PreferredOrderCat = 'Laptop & Accessory'
       GROUP BY CityTier
       ORDER BY ChrunedCount DESC
       Limit 1;
       
       
	--  Most preferred payment mode among active customers
	   SELECT PreferredPaymentMode,
       Count(*) as Count
       FROM customer_churn
       WHERE ChurnStatus = 'Active'
       GROUP BY PreferredPaymentMode
       ORDER BY Count DESC
       Limit 1;
       -- debit card.
       
	-- Calculate total order amount hike
       SELECT 
		   Sum(OrderAmountHikeFromlastYear) as TotalOrderAmountHike
	   FROM customer_churn
       WHERE MaritalStatus = 'Single'
		 AND PreferredOrderCat = 'Mobile Phone';
	-- 12177.
    
    
	-- Avg no of device used by customers who used UPI
       SELECT avg(NumberOfDeviceRegistered) as AvgDevices
       From  customer_churn
       WHERE PreferredPaymentMode = 'UPI';
	-- 3.7174.
         
	-- City tier with Highest no of Customers
       SELECT CityTier,
       Count(*) as CustomerCount
       FROM  customer_churn
       GROUP BY CityTier
       ORDER BY CustomerCount DESC
       Limit 1;
    -- CityTier 1 has Highest no of customeCount as 3666
    
    -- gender that utilized the highest number of coupons
	   SELECT Gender,
       Sum(CouponUsed) as TotalCoupons
       FROM customer_churn
       GROUP BY Gender
       ORDER BY TotalCoupons DESC
       Limit 1;
	-- Male Gender Utilized the highest no of coupons as 5629
    
    -- No of customers and max hrs spent on app
       SELECT PreferredOrderCat,
		   COUNT(*) as CustomerCount,
           MAX(HoursSpentOnApp) as MaxHours
	   FROM customer_churn
       GROUP BY PreferredOrderCat;
    
    
    -- total order count for customers prefer  credit cards and have the maximum satisfaction score
       SELECT 
		  sum(OrderCount) as TotalOrederCount
       FROM customer_churn
       WHERE PreferredPaymentMode = 'CreditCard'
         AND SatisfactionScore = (
                                 SELECT MAX(SatisfactionScore)
                                 FROM customer_churn);
          
          
	--  average satisfaction score of customers who have complained
		SELECT AVG(SatisfactionScore) as AvgSatisfaction
        FROM  customer_churn
        WHERE ComplaintReceived = 'Yes';
	-- average satisfaction score of customers who have complained is 2.9988
    
    -- order category among customers who used > than 5 coupons
       SELECT PreferredOrderCat,
       COUNT(*) as Count
       FROM customer_churn
       WHERE CouponUsed > 5
       GROUP BY PreferredOrderCat
       ORDER BY Count DESC
       Limit 1;
       -- Laptop & Accessory 
       -- COUNT 99
    
    --  top 3 preferred order categories with the highest average cashback amount
		SELECT PreferredOrderCat,
		AVG(CashbackAmount)as AvgCashBack
        FROM customer_churn
        GROUP BY PreferredOrderCat
        ORDER BY AvgCashBack DESC
        Limit 3;
        
        
	--  payment modes of customers Avg tenure = 10 mths and orders > 500
        SELECT PreferredPaymentMode
        FROM customer_churn
        WHERE Tenure = 10
		  AND OrderCount > 500;
    
    
    -- Categorize Customers based on warehouseToHome 
    
	    SELECT 
           CASE 
              WHEN WarehouseToHome <= 5 THEN 'Very Close Distance'
              WHEN WarehouseToHome <= 10 THEN 'Close Distance'
              WHEN WarehouseToHome <= 15 THEN 'Moderate Distance'
              ELSE 'Far Distance'
           END AS DistanceCategory,
              COUNT(*) AS CustomerCount,
			  SUM(CASE WHEN ChurnStatus = 'Churned' THEN 1 ELSE 0 END) AS ChurnedCustomers,
              SUM(CASE WHEN ChurnStatus = 'Active' THEN 1 ELSE 0 END) AS ActiveCustomers
       FROM customer_churn
       GROUP BY DistanceCategory;
       
       
	-- Customer details who are married,live in city tier-1,and have order count> avg orders of all customers
       SELECT *
       FROM customer_churn
       WHERE MaritalStatus = 'Married'
         AND CityTier = 1
         AND OrderCount > (SELECT AVG(OrderCount)
	   FROM customer_churn);
       
       
      
   -- CREATION OF CUSTOMERS_RETURN TABLE   
      
      USE ecommerce;
      CREATE TABLE Customer_return (
         ReturnID INT primary key,
         CustomerID INT,
         ReturnDate Date,
         RefundAmount Decimal(10,2)
	  );
      
      DROP TABLE Customers_return;
      
     INSERT INTO customer_return ( ReturnID, CustomerID, ReturnDate, RefundAmount) VALUES
     (1001, 50022, '2023-01-01', 2130),
     (1002, 50316, '2023-01-23', 2000),
	 (1003, 51099, '2023-02-14', 2200),
     (1004, 52321, '2023-03-08', 2510),
     (1005, 52928, '2023-03-20', 3000),
     (1006, 53749, '2023-04-17', 1740),
     (1007, 54206, '2023-04-21', 3250),
     (1008, 54838, '2023-04-30', 1990);
     
     
  -- Display Retuned details + Churned customers who complained
  -- Query to join and Filter
     SELECT 
         cr.ReturnID,
         cr.CustomerID,
		 cr.ReturnDate,
         cr.RefundAmount,
         cc.Tenure,
		 cc.Gender,
		 cc.PreferredPaymentMode,
         cc.PreferredOrderCat,
         cc.ChurnStatus,
         cc.ComplaintReceived
    FROM 
         customer_return cr
    JOIN 
         customer_churn cc
	ON 
         cr.CustomerID = cc.CustomerID
    WHERE
         cc.ChurnStatus = 'Churned'
         and cc.ComplaintReceived = 'Yes';
         
         
         
         
     
    